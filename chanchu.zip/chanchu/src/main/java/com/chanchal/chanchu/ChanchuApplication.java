package com.chanchal.chanchu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChanchuApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChanchuApplication.class, args);
	}

}
