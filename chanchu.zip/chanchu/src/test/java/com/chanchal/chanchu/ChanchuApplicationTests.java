package com.chanchal.chanchu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChanchuApplicationTests {

	@Test
	void contextLoads() {
	}

}
