package com.given.MyfirstAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
